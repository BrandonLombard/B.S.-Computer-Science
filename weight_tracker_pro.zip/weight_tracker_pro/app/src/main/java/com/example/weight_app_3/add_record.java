package com.example.weight_app_3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

public class add_record extends AppCompatActivity {
    private EditText mDate;
    private EditText mWeight;
    private weight_app_database mDatabase;
    private Calendar myCalendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_record2);
        mDate = findViewById(R.id.input_date);
        mWeight = findViewById(R.id.input_weight);
        mDatabase = weight_app_database.getInstance(getApplicationContext());
    }

    public void addWeight(android.view.View view) {
        Toast.makeText(getApplicationContext(), mDate.getText().toString() + mWeight.getText().toString(), Toast.LENGTH_LONG).show();
        //String sDate = date.getDate() + "/" + (date.getMonth()+1) + "/" + (1900 + date.getYear());
        String sDate = mDate.getText().toString();
        String sWeight = mWeight.getText().toString();
        DailyWeight dailyWeight = new DailyWeight(sDate, sWeight);
        if (mDatabase.addDailyWeight(dailyWeight)) {
            Toast.makeText(getApplicationContext(), "Added Successfully!", Toast.LENGTH_LONG).show();
        }
        else { Toast.makeText(getApplicationContext(), "An Error Occurred", Toast.LENGTH_LONG).show(); }
    }
    // menu handling
    public void onClickHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void onClickHistory(View view) {
        Intent intent = new Intent(this, history.class);
        startActivity(intent);
    }
    public void onClickAddRecord(View view) {
        Intent intent = new Intent(this, add_record.class);
        startActivity(intent);
    }
    public void onClickWeightGoal(View view) {
        Intent intent = new Intent(this, edit_goal.class);
        startActivity(intent);
    }
    public void onClickSettings(View view) {
        Intent intent = new Intent(this, settings.class);
        startActivity(intent);
    }
}
