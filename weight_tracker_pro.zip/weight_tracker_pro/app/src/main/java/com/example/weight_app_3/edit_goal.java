package com.example.weight_app_3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class edit_goal extends AppCompatActivity {
    private TextView mCurrentTargetVal;
    private EditText mEditTargetVal;
    private Button mSubmitButton;
    private weight_app_database mDatabase;
    private String updateTarget;
    private TargetWeight mTargetWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_goal);
        mDatabase = weight_app_database.getInstance(getApplicationContext());
        mCurrentTargetVal = findViewById(R.id.current_target);
        mEditTargetVal = findViewById(R.id.target_weight_edit);
        mSubmitButton = findViewById(R.id.target_edit_button);
        mTargetWeight = mDatabase.getTargetWeight();
        if (mTargetWeight != null) {
            updateTarget = mTargetWeight.getWeight();
            mCurrentTargetVal.setText(updateTarget);
        }
    }
    public void onClick(android.view.View view) {
        String newWeight = mEditTargetVal.getText().toString();
        Toast.makeText(getApplicationContext(), newWeight, Toast.LENGTH_LONG).show();
        TargetWeight targetWeight = new TargetWeight(newWeight);
        mTargetWeight = mDatabase.getTargetWeight();
        if (mTargetWeight != null) {
            Toast.makeText(getApplicationContext(), targetWeight.getWeight(), Toast.LENGTH_LONG).show();
            mDatabase.updateTarget(targetWeight);
            mCurrentTargetVal.setText(targetWeight.getWeight());
        }
        else {
            mDatabase.addTarget(targetWeight);
            Toast.makeText(getApplicationContext(), "Target Added!", Toast.LENGTH_LONG).show();
        }
    }

    // menu handling
    public void onClickHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void onClickHistory(View view) {
        Intent intent = new Intent(this, history.class);
        startActivity(intent);
    }
    public void onClickAddRecord(View view) {
        Intent intent = new Intent(this, add_record.class);
        startActivity(intent);
    }
    public void onClickWeightGoal(View view) {
        Intent intent = new Intent(this, edit_goal.class);
        startActivity(intent);
    }
    public void onClickSettings(View view) {
        Intent intent = new Intent(this, settings.class);
        startActivity(intent);
    }
}