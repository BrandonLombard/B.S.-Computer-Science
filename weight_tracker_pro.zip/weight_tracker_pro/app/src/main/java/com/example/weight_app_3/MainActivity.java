package com.example.weight_app_3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.content.Context;
import android.content.Intent;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.view.MenuItem;


import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.jetbrains.annotations.NotNull;

public class MainActivity extends AppCompatActivity {
    private weight_app_database mDatabase;
    private TextView mCurrentTarget;
    private TextView mCurrentWeight;
    private TargetWeight mTargetWeight;
    private DailyWeight mDailyWeight;
    private String updateTarget;
    private String updateCurrent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // initialize database
        mDatabase = weight_app_database.getInstance(getApplicationContext());
        mCurrentTarget = findViewById(R.id.target_weight_value);
        mCurrentWeight = findViewById(R.id.current_weight_value);
        //obtain dynamic elements
        mTargetWeight = mDatabase.getTargetWeight();
        // fetches the most recent weight only
        mDailyWeight = mDatabase.getSingleDailyWeight();
        // updates the text only if there is a target weight and daily weight record
        // inline toasts were for debugging - left in for further debugging
        if (mTargetWeight != null) {
            updateTarget = mTargetWeight.getWeight();
            //Toast.makeText(getApplicationContext(), mTargetWeight.getWeight(), Toast.LENGTH_LONG).show();
            mCurrentTarget.setText(updateTarget);
        }
        else if (mTargetWeight == null) {
            Toast.makeText(getApplicationContext(), "No Set Target", Toast.LENGTH_LONG).show();
        }
        if (mDailyWeight != null) {
            updateCurrent = mDailyWeight.getWeight();
            //Toast.makeText(getApplicationContext(), updateCurrent, Toast.LENGTH_LONG).show();
            //String sWeight = mDailyWeight.getWeight();
            mCurrentWeight.setText(updateCurrent);
        }
    }
    // handling for a button no longer in use - left in for debugging
    public void onClick(View view) {
        mTargetWeight = mDatabase.getTargetWeight();
        mDailyWeight = mDatabase.getSingleDailyWeight();
        if (mTargetWeight != null) {
            updateTarget = mTargetWeight.getWeight();
            Toast.makeText(getApplicationContext(), mTargetWeight.getWeight(), Toast.LENGTH_LONG).show();
            mCurrentTarget.setText(updateTarget);
        }
        else if (mTargetWeight == null) {
            Toast.makeText(getApplicationContext(), "No Set Target", Toast.LENGTH_LONG).show();
        }
        if (mDailyWeight != null) {
            updateCurrent = mDailyWeight.getWeight();
            Toast.makeText(getApplicationContext(), updateCurrent, Toast.LENGTH_LONG).show();
            //String sWeight = mDailyWeight.getWeight();
            mCurrentWeight.setText(updateCurrent);
        }
    }
    // menu handling
    public void onClickHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void onClickHistory(View view) {
        Intent intent = new Intent(this, history.class);
        startActivity(intent);
    }
    public void onClickAddRecord(View view) {
        Intent intent = new Intent(this, add_record.class);
        startActivity(intent);
    }
    public void onClickWeightGoal(View view) {
        Intent intent = new Intent(this, edit_goal.class);
        startActivity(intent);
    }
    public void onClickSettings(View view) {
        Intent intent = new Intent(this, settings.class);
        startActivity(intent);
    }

}
